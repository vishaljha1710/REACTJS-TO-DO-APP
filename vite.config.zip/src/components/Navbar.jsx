

export const Navbar = () => {
  return (
    <div>Navbar</div>
  )
}
