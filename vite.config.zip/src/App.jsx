import { Todo } from "./components/Todo";


const App=()=>{

    return(
        <div>
            
         <Todo></Todo>

            
        </div>

        
    )
}
export default App